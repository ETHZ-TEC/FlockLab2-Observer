// no contents for assembler only
