from msp430.bsl5 import bsl5
from msp430.bsl5.uart import SerialBSL5Target
import msp430.memory
import logging
import time
import serial

MSP432_INFOMEM_ADDR = 0x00200000
MSP432_INFOMEM_SIZE = 0x00004000

class SerialBSL32Target(SerialBSL5Target):

	def __init__(self):
		SerialBSL5Target.__init__(self)
	
	# override SerialBSL5
	def start_bsl(self):
		self.serial.flushInput()    # clear buffers
		# todo for generic implementation: MSP432 uses a different BSL entry pattern
		time.sleep(0.1)
		self.set_RST(False)     # RST  pin: GND
		self.set_TEST(True)     # TEST pin: GND
		self.set_TEST(False)    # TEST pin: Vcc
		self.set_RST(True)      # RST  pin: Vcc
		self.set_TEST(True)     # TEST pin: GND
		time.sleep(0.1)
		# auto baud
		self.serial.write('\xff')
		ack = self.serial.read(1)
		if ack != '\x00': raise bsl5.BSL5Error('No ACK received for auto-baud detection (timeout).')
	
	# override SerialBSL5
	def open(self, baudrate, port=0, ignore_answer=False):
		self.ignore_answer = ignore_answer
		self.logger.info('Opening serial port %r' % port)
		try:
			self.serial = serial.serial_for_url(
				port,
				baudrate=baudrate,
				parity=serial.PARITY_EVEN,
				stopbits=serial.STOPBITS_ONE,
				timeout=1,
			)
		except AttributeError:  # old pySerial versions do not have serial_for_url
			self.serial = serial.Serial(
				port,
				baudrate=baudrate,
				parity=serial.PARITY_EVEN,
				stopbits=serial.STOPBITS_ONE,
				timeout=1,
			)
			
	# override SerialBSL5Target
	def open_connection(self):
		self.logger = logging.getLogger('BSL')
		if self.options.speed is None:
			 self.options.speed = 9600
		self.open(
			self.options.speed,
			self.options.port,
			ignore_answer = self.options.ignore_answer,
		)
		self.control_delay = self.options.control_delay

		if self.options.test_on_tx:
			self.testOnTX = True

		if self.options.invert_test:
			self.invertTEST = True

		if self.options.invert_reset:
			self.invertRST = True

		if self.options.swap_reset_test:
			self.swapResetTest = True

		self.set_TEST(True)
		self.set_RST(True)

		if self.options.start_pattern:
			self.logger.info("Start pattern...")
			self.start_bsl()
		
		if self.options.do_mass_erase:
			self.logger.info("Mass erase...")
			try:
				self.BSL32_RX_PASSWORD('\xff'*254 + '\0'*2)
			except bsl5.BSL5Error:
				pass # it will fail - that is our intention to trigger the erase
			self.BSL32_RX_PASSWORD('\xff'*256)
			# remove mass_erase from action list so that it is not done
			# twice
			self.remove_action(self.mass_erase)
		else:
			if self.options.password is not None:
				password = msp430.memory.load(self.options.password).get_range(0x0, 0xff)
				self.logger.info("Transmitting password: %s" % (str(password).encode('hex'),))
				self.BSL32_RX_PASSWORD(password)
		
	# override BSL5
	def memory_write(self, address, data):
		if address >= MSP432_INFOMEM_ADDR and address + len(data) <= MSP432_INFOMEM_ADDR + MSP432_INFOMEM_SIZE:
			raise bsl5.BSL5Error('Writing to information memory is not permitted.')
		super(SerialBSL32Target, self).memory_write(address, data)
				
def main():    
	# run the main application
	bsl_target = SerialBSL32Target()
	bsl_target.main()

if __name__ == '__main__':
	main()
