#!/usr/bin/env python

# command line stub for
# https://launchpad.net/python-msp430-tools

import msp430.memory.convert
msp430.memory.convert.main()
