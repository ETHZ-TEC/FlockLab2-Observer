#!/usr/bin/env python

# command line stub for
# https://launchpad.net/python-msp430-tools

import msp430.gdb.target
msp430.gdb.target.main()
